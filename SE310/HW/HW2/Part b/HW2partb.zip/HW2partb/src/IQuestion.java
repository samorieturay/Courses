public interface IQuestion {
    String getPrompt();
    void setPrompt(String prompt);
    void displayQuestion();
}