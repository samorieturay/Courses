public interface IResponse {
    boolean isValid();
}